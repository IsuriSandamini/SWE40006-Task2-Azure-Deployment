using CloudDeploymentDashboard.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace CloudDeploymentDashboard.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IConfiguration _configuration;

        public HomeController(
            ILogger<HomeController> logger,
            IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }

        public IActionResult Index()
        {
            ViewBag.DeploymentMessage =
                _configuration["DeploymentMessage"]
                ?? "Configuration value not found";

            _logger.LogInformation(
        "Cloud Deployment Dashboard homepage was requested at {Time}",
        DateTime.UtcNow);

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel
            {
                RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier
            });
        }
    }
}